# ÉTERA — Fitness Journal

Aplicación de registro fitness hecha con HTML, CSS y JavaScript, con una envoltura Android nativa basada en WebView.

## Funciones
- Panel de inicio con actividad semanal y resumen mensual.
- Rutinas editables, ejercicios, series, repeticiones y peso.
- Marcar series completadas y registrar duración.
- Historial de entrenamientos y gráfico simple de actividad.
- Registro manual de peso, cintura y cadera.
- Perfil y objetivo personal.
- Exportación de datos a JSON.
- Persistencia local con `localStorage`; no requiere cuenta.
- Interfaz responsive y soporte PWA/offline en navegador compatible.

## Abrir la versión web
Abrí `www/index.html` en un navegador. Para instalarla como PWA, serví la carpeta `www` mediante un servidor local HTTPS o localhost y usá la opción "Añadir a pantalla de inicio".

## Generar APK con Android Studio
Este paquete incluye el proyecto Android nativo en la carpeta `android/` y los recursos web en `android/app/src/main/assets/www/`.

1. Instalá Android Studio y el Android SDK Platform 35.
2. Abrí la carpeta raíz del proyecto (`etera-fitness`) en Android Studio.
3. Si Android Studio solicita sincronizar Gradle, aceptá la sincronización y permití que descargue el Android Gradle Plugin/Gradle.
4. Seleccioná **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. El APK de depuración se generará en `android/app/build/outputs/apk/debug/app-debug.apk`.

También podés compilar desde una terminal con Gradle 8.9 instalado y Android SDK configurado:

```bash
gradle :app:assembleDebug
```

> Nota: no se incluyó un APK compilado en esta entrega porque el entorno de generación no dispone de Android SDK ni Gradle instalados. El proyecto Android queda preparado para abrir y compilar en Android Studio.

## Estructura
- `www/`: aplicación web (HTML/CSS/JS), manifest, service worker e icono.
- `android/`: proyecto Android WebView que carga la aplicación localmente.

## Datos y privacidad
Los entrenamientos y medidas se almacenan localmente en el dispositivo. No hay backend, inicio de sesión ni sincronización en la nube. Exportá tus datos desde Perfil si querés guardar una copia.
